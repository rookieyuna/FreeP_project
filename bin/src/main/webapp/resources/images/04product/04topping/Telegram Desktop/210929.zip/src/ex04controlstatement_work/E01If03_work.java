package ex04controlstatement_work;

public class E01If03_work {

	public static void main(String[] args) {

		/*
		 시나리오] 국,영,수 점수의 평균값을 구하여 학점을 출력하는 프로그램을
		 	작성하시오. 90점이상은 A학점...
		 	60점 미만은 F학점을 출력하면 된다.
		 */
		
		
		
		
		
		
	}
}
