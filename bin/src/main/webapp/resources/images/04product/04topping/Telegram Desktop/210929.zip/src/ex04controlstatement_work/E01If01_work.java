package ex04controlstatement_work;

import java.util.Scanner;

public class E01If01_work {

	public static void main(String[] args) {

		/*
		 시나리오] 사용자가 입력한 문자가 숫자인지 판단하는 프로그램을
		 		   if문을 이용해서 작성하시오.
		 */
		
		Scanner scanner = new Scanner(System.in);
		
		
		
		
		
		
	}

}
