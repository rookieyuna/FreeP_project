package ex04controlstatement_work;

public class E03While_work {

	public static void main(String[] args) {

		/*
		 시나리오] 1~10까지의 합을 구하는 프로그램을 while문으로 작성하시오.
		  ※ 복합대입연산자 사용
		 */
			//작성1 : 10번 반복하기 위한 while문을 만든다.

		
		
		
		
		
		System.out.println();
		System.out.println("\n==============================\n");
		/*
		 시나리오] 1~100까지의 정수중 3의 배수이거나 4의배수인
		 	정수의 합을 구하는 프로그램을 while문을 이용해서 작성하시오.
		 */
		
		
		
		System.out.println();
		System.out.println("\n==============================\n");
		/*
		 시나리오] 구구단을 출력하는 프로그램을 작성하시오.
		 단, while문을 이용하시오.
		 */
		
		
		
	
		System.out.println();
		System.out.println("\n==============================\n");
		/*
		 시나리오] 아래와 같은 모양을 출력하는 while문을 작성하시오.
		 	출력결과
		 		1 0 0 0
		 		0 1 0 0 
		 		0 0 1 0
		 		0 0 0 1
		 */
		
	
		
		
		
		
		
		
	}

}
