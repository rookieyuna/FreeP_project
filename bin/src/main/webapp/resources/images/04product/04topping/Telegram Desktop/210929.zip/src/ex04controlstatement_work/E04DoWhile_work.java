package ex04controlstatement_work;

public class E04DoWhile_work {

	public static void main(String[] args) {

		/*
		 시나리오 ] E03 예제의 1~10까지 더하는 수열문제를 do~while문으로
		 	변경하여 구하시오.
		 */
		
		
		
		System.out.println();
		System.out.println("\n==============================\n");
		/*
		 시나리오 ]  1부터 1000까지의 정수중 4의 배수이거나 7의 배수인 수의
		 	합을 수하여 출력하는 프로그램을 작성하시오.
		 	단, do~while문을 사용해야한다.
		 */
		
		
		
		
		
		System.out.println();
		System.out.println("\n==============================\n");
		/*
		 시나리오 ] 국어, 영어, 수학 점수를 사용자로부터 입력받은 후
		 	평균을 구해 A~F학점을 판단하여 출력하는 프로그램을 작성하시오.
		 	단, 사용자가  X,x(대소문자 구분없음)를 입력하면 프로그램이
		 	종료되어야 하며 do~while 문으로 구현해야 한다.
		 */
		
	}

}
