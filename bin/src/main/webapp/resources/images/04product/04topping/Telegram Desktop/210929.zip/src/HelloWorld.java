
public class HelloWorld {

	public static void main(String[] args) {
		System.out.println("안녕하세요? 이클립스");
		System.out.println("Hello world");
		
		System.out.println("0Oo il");
	}

}
