package ex04controlstatement_work;

public class E02Switch_work {

	public static void main(String[] args) {

		/*
		 시나리오] 지금의 계절을 switch문을 통하여 구하시오.
		 	3 ~ 5월	 : 봄
		 	6 ~ 9월	 : 여름
		 	10월	 : 가을
		 	11 ~ 2월 : 겨울
		 */
		
		
		
		
		
		
		
		
		
		
		
		
		
	}

}
