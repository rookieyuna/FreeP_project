package ex04controlstatement_work;

public class E05For_work {

	public static void main(String[] args) {
	
		/*
		 시나리오] 1~100까지의 합을 구하는 프로그램을
		 	for문을 이용하여 작성하시오.
		 */

		
		
		
		
		System.out.println();
		System.out.println("\n==============================\n");
		/*시나리오]
		  for문을 이용하여 1~10사이의 정수 중 2의 배수의 합을 구하는
		  프로그램을 작성하시오.
		 */
		
		
		System.out.println();
		System.out.println("\n==============================\n");
		/*
		 연습문제1] 구구단을 출력하는 프로그램을 for문으로 작성하시오
		 */
		
		
		
		
		
		System.out.println();
		System.out.println("\n==============================\n");
		/*
		 연습문제2] 다음의 출력결과를 보이는 for문을 작성하시오
		 출력결과
		 	0 0 0 1
		 	0 0 1 0
		 	0 1 0 0
		 	1 0 0 0
		 해법 : x와 y를 더해서 5가 될 때 1을 출력한다.
		 */
		
		
		
		
		
		
		
		
		
		
	}
	
}
