package ex04controlstatement_work;

public class E01If02_work {

	public static void main(String[] args) {

		/*
		 시나리오] 숫자를 홀/짝인지 먼저 판단한 후 100이상인지를 판단하는
		  프로그램을 if~else문으로 작성하시오.
		 */
		
		
		
	}

}
